Zerotier or Tailscale are a necessity for this app, if you want to connect to PC's outside of your subnet.
They're free, take 5 minutes to setup.
www.zerotier.com
www.tailscale.com