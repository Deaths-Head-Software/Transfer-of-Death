#!/usr/bin/env python3
"""
Transfer of Death - High-Speed Peer-to-Peer File Transfer Application
Cloned from Chat of Death by Death's Head Software
Optimized for terabyte-scale data transfers
v1.5 - Speed optimizations, Winsock repair, Windows DPI button fix, full IP detection: proper cleanup on reconnect, configurable
        listen port, multi-IP detection, disconnect button, ACK routing fix
"""

import sys
import time
import socket
import os
import struct
from pathlib import Path
from enum import IntEnum
import threading

# --- Helper Functions ---
def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

def format_file_size(bytes_size):
    if bytes_size < 0:
        return "0 B"
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_size < 1024.0:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024.0
    return f"{bytes_size:.2f} PB"

def load_app_icon():
    """Load icon.ico for taskbar/window. Falls back to splash.png."""
    from PyQt6.QtGui import QIcon
    for name in ["icon.ico", "splash.png"]:
        path = Path(resource_path(name))
        if path.exists():
            return QIcon(str(path))
    return None

def get_all_local_ips():
    """Get ALL local IP addresses including VPN/Tailscale interfaces."""
    ips = []

    # Method 1: getaddrinfo on hostname (works on most platforms)
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None, socket.AF_INET):
            ip = info[4][0]
            if ip != '127.0.0.1' and ip not in ips:
                ips.append(ip)
    except:
        pass

    # Method 2: routing-based detection (finds the "main" outbound IP)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip not in ips:
            ips.insert(0, ip)
    except:
        pass

    # Method 3: Probe multiple routing targets to discover all active interfaces
    # Works on Windows, Mac, and Linux - finds VPN/Tailscale IPs the hostname method misses
    test_targets = [
        ("1.1.1.1", 80),      # Public internet
        ("100.64.0.1", 80),   # Tailscale CGNAT range (100.x.x.x)
        ("10.0.0.1", 80),     # Common VPN/LAN range
        ("192.168.1.1", 80),  # Common home LAN
        ("172.16.0.1", 80),   # Common corporate range
    ]
    for target in test_targets:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(target)
            ip = s.getsockname()[0]
            s.close()
            if ip not in ips and ip != '127.0.0.1':
                ips.append(ip)
        except:
            pass

    if not ips:
        ips = ["127.0.0.1"]
    return ips

# --- Global Definitions ---
APP_NAME = "Transfer of Death"
ORG_NAME = "Death's Head Software"

class DataPacketType(IntEnum):
    CHAT = 1
    NICKNAME = 3
    FILE_START = 5
    FILE_CHUNK = 6
    FILE_END = 7
    FILE_CANCEL = 8
    FILE_ACK = 9

try:
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QTextEdit, QPushButton, QLabel, QLineEdit, QTabWidget,
        QTableWidget, QTableWidgetItem, QSplashScreen, QScrollArea,
        QGroupBox, QProgressBar, QAbstractItemView,
        QFileDialog, QMessageBox, QSizePolicy, QHeaderView
    )
    from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSettings
    from PyQt6.QtGui import QPixmap, QPainter, QColor, QFont, QAction
    LIBS_AVAILABLE = True
except ImportError as e:
    LIBS_AVAILABLE = False
    print(f"FATAL ERROR: Missing dependency. Run 'pip install PyQt6'. Details: {e}")
    sys.exit(1)


# --- FILE TRANSFER MANAGER ---

class FileTransferManager(QThread):
    progress_update = pyqtSignal(int, int)
    transfer_complete = pyqtSignal()
    transfer_error = pyqtSignal(str)
    thread_finished = pyqtSignal()

    def __init__(self, sock, filepath: str):
        super().__init__()
        self.sock = sock
        self.filepath = filepath
        self.is_cancelled = False
        self.chunk_size = 256 * 1024  # 256KB - optimal for relay/VPN, avoids TCP congestion
        self.last_progress_percent = -1
        self.ack_received = threading.Event()
        self._cleanup_requested = False

    def cancel(self):
        self.is_cancelled = True

    def acknowledge_received(self):
        self.ack_received.set()

    def request_cleanup(self):
        self._cleanup_requested = True

    def run(self):
        try:
            path = Path(self.filepath)
            if not path.exists():
                self.transfer_error.emit("File not found")
                return

            filename = path.name
            filesize = path.stat().st_size
            print(f"FILE SEND: Starting {filename}, {format_file_size(filesize)}")

            try:
                filename_bytes = filename.encode('utf-8')
                metadata = struct.pack('!QH', filesize, len(filename_bytes)) + filename_bytes
                self.sock.send_data(metadata, DataPacketType.FILE_START)
                print("FILE SEND: Waiting for ACK...")
                if not self.ack_received.wait(timeout=90):
                    self.transfer_error.emit("Receiver did not acknowledge - transfer cancelled")
                    return
                print("FILE SEND: ACK received, transferring...")
            except Exception as e:
                self.transfer_error.emit(f"Failed to send file info: {e}")
                return

            bytes_sent = 0
            chunk_count = 0
            with open(self.filepath, 'rb') as f:
                while bytes_sent < filesize and not self.is_cancelled:
                    chunk = f.read(self.chunk_size)
                    if not chunk:
                        break
                    try:
                        self.sock.send_data(chunk, DataPacketType.FILE_CHUNK)
                    except Exception as e:
                        self.transfer_error.emit(f"Connection lost at {bytes_sent} bytes")
                        return
                    bytes_sent += len(chunk)
                    chunk_count += 1
                    progress_percent = int((bytes_sent / filesize) * 100)
                    # Only emit every 2% to reduce cross-thread signal overhead
                    if progress_percent >= self.last_progress_percent + 2:
                        self.progress_update.emit(bytes_sent, filesize)
                        self.last_progress_percent = progress_percent
                        if progress_percent % 10 == 0:
                            print(f"FILE SEND: {progress_percent}% ({format_file_size(bytes_sent)})")

            if self.is_cancelled:
                try:
                    self.sock.send_data(b'', DataPacketType.FILE_CANCEL)
                except:
                    pass
                self.transfer_error.emit("Transfer cancelled")
            else:
                try:
                    time.sleep(0.2)
                    self.sock.send_data(b'', DataPacketType.FILE_END)
                    self.transfer_complete.emit()
                    print(f"FILE SEND: Complete - {format_file_size(bytes_sent)}")
                except Exception as e:
                    self.transfer_error.emit(f"Error completing transfer: {e}")
        except Exception as e:
            self.transfer_error.emit(str(e))
        finally:
            self.thread_finished.emit()


# --- SOCKET WRAPPER ---

class DirectSocket:
    def __init__(self, raw_socket: socket.socket):
        self.raw_socket = raw_socket
        self._lock = threading.Lock()
        self._configure_socket()

    def _configure_socket(self):
        if not self.raw_socket:
            return
        try:
            self.raw_socket.settimeout(7200)
            self.raw_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self.raw_socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 8 * 1024 * 1024)
            self.raw_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 8 * 1024 * 1024)
            self.raw_socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            if hasattr(socket, 'TCP_KEEPIDLE'):
                self.raw_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 30)
            if hasattr(socket, 'TCP_KEEPINTVL'):
                self.raw_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 10)
            if hasattr(socket, 'TCP_KEEPCNT'):
                self.raw_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 9)
            if sys.platform == 'win32':
                self.raw_socket.ioctl(socket.SIO_KEEPALIVE_VALS, (1, 30000, 10000))
            print("Socket configured (keepalive, 2hr timeout)")
        except Exception as e:
            print(f"Socket config warning: {e}")

    def send_raw(self, data: bytes):
        with self._lock:
            self.raw_socket.sendall(data)

    def send_data(self, data: bytes, data_type: DataPacketType):
        header = struct.pack('!BI', data_type, len(data))
        # Combine header+data into one sendall to avoid two syscalls per chunk
        with self._lock:
            self.raw_socket.sendall(header + data)

    def recv_all(self, n: int) -> bytes:
        data = bytearray()
        while len(data) < n:
            try:
                packet = self.raw_socket.recv(min(262144, n - len(data)))
                if not packet:
                    raise ConnectionError("Socket closed")
                data.extend(packet)
            except socket.timeout:
                raise ConnectionError("Socket timeout")
        return bytes(data)

    def close(self):
        try:
            self.raw_socket.shutdown(socket.SHUT_RDWR)
        except:
            pass
        try:
            self.raw_socket.close()
        except:
            pass


# --- SOCKET LISTENER THREAD ---

class SocketListener(QThread):
    new_message = pyqtSignal(bytes)
    peer_nickname_received = pyqtSignal(bytes)
    file_start_received = pyqtSignal(str, object)
    file_chunk_received = pyqtSignal(bytes)
    file_end_received = pyqtSignal()
    file_cancel_received = pyqtSignal()
    file_ack_received = pyqtSignal()
    connection_lost = pyqtSignal(str)

    def __init__(self, sock: DirectSocket):
        super().__init__()
        self.sock = sock
        self.running = True

    def stop(self):
        self.running = False

    def run(self):
        print("Listener started")
        try:
            while self.running:
                try:
                    header = self.sock.recv_all(5)
                    packet_type, length = struct.unpack('!BI', header)

                    if packet_type == DataPacketType.CHAT:
                        self.new_message.emit(self.sock.recv_all(length))
                    elif packet_type == DataPacketType.NICKNAME:
                        self.peer_nickname_received.emit(self.sock.recv_all(length))
                    elif packet_type == DataPacketType.FILE_START:
                        data = self.sock.recv_all(length)
                        filesize, filename_len = struct.unpack('!QH', data[:10])
                        filename = data[10:10+filename_len].decode('utf-8')
                        print(f"FILE RECEIVE: FILE_START {filename} {format_file_size(filesize)}")
                        self.file_start_received.emit(filename, filesize)
                    elif packet_type == DataPacketType.FILE_CHUNK:
                        self.file_chunk_received.emit(self.sock.recv_all(length))
                    elif packet_type == DataPacketType.FILE_END:
                        self.sock.recv_all(length)
                        self.file_end_received.emit()
                    elif packet_type == DataPacketType.FILE_CANCEL:
                        self.sock.recv_all(length)
                        self.file_cancel_received.emit()
                    elif packet_type == DataPacketType.FILE_ACK:
                        self.sock.recv_all(length)
                        self.file_ack_received.emit()

                except (ConnectionError, ConnectionResetError, ConnectionAbortedError, OSError) as e:
                    self.connection_lost.emit(f"Connection lost: {type(e).__name__}")
                    break
        except Exception as e:
            self.connection_lost.emit(f"Listener error: {e}")
        print("Listener stopped")


# --- SERVER LISTENER THREAD ---

class ServerListener(QThread):
    new_connection = pyqtSignal(object)

    def __init__(self, port: int):
        super().__init__()
        self.port = port
        self.running = True
        self.server_socket = None

    def stop(self):
        self.running = False
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass

    def run(self):
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(('0.0.0.0', self.port))
            self.server_socket.listen(5)
            self.server_socket.settimeout(1.0)
            print(f"Server listening on port {self.port}")
            while self.running:
                try:
                    client_socket, addr = self.server_socket.accept()
                    print(f"New connection from {addr[0]}:{addr[1]}")
                    self.new_connection.emit(DirectSocket(client_socket))
                except socket.timeout:
                    continue
                except Exception as e:
                    if self.running:
                        print(f"Accept error: {e}")
        except Exception as e:
            print(f"Server error: {e}")


# --- MAIN WINDOW ---

class TransferOfDeath(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} v1.5")
        # Explicitly allow maximize on Linux window managers
        self.setWindowFlags(
            Qt.WindowType.Window
            | Qt.WindowType.WindowMinimizeButtonHint
            | Qt.WindowType.WindowMaximizeButtonHint
            | Qt.WindowType.WindowCloseButtonHint
        )
        icon = load_app_icon()
        if icon:
            self.setWindowIcon(icon)

        self.settings = QSettings(ORG_NAME, APP_NAME)
        geometry_data = self.settings.value("geometry")
        if geometry_data:
            self.restoreGeometry(geometry_data)
        else:
            self.setGeometry(100, 100, 1400, 900)
        self.setMinimumSize(800, 500)

        self.is_dark_mode = self.settings.value("dark_mode", True, type=bool)
        self.local_nickname = self.settings.value("local_nickname", "Anonymous", type=str)
        default_download = str(Path.home() / "Downloads")
        self.download_directory = self.settings.value("download_directory", default_download, type=str)
        self.server_port = self.settings.value("server_port", 8000, type=int)

        self.local_ips = get_all_local_ips()
        self.peer_nickname = "Peer"
        self.current_peer_socket = None
        self.server_listener = None
        self.listener_thread = None
        self.transfer_manager = None
        self.selected_file_path = ""
        self.receiving_file = False
        self.incoming_file = None
        self.incoming_filename = ""
        self.incoming_filesize = 0
        self.incoming_bytes_received = 0
        self.current_transfer_id = None
        self.transfer_rows = {}
        self.transfer_managers = {}
        self.transfer_sizes = {}
        self.next_transfer_id = 0

        self.init_ui()
        self.apply_theme()
        self.start_server()

    def init_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)

        menubar = self.menuBar()
        file_menu = menubar.addMenu("File")
        exit_action = QAction("Exit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        view_menu = menubar.addMenu("View")
        theme_action = QAction("Toggle Dark/Light Mode", self)
        theme_action.triggered.connect(self.toggle_theme)
        view_menu.addAction(theme_action)

        # --- Connection Info ---
        info_group = QGroupBox("Connection Information")
        info_layout = QVBoxLayout()

        # Show ALL detected IPs - wrap if many interfaces
        ip_row = QHBoxLayout()
        ips_display = "\n".join(self.local_ips) if len(self.local_ips) > 3 else "  |  ".join(self.local_ips)
        self.local_ip_label = QLabel(f"Your IPs: {ips_display}")
        self.local_ip_label.setFont(QFont("Courier", 9))
        self.local_ip_label.setWordWrap(True)
        ip_row.addWidget(self.local_ip_label, stretch=1)
        refresh_ip_btn = QPushButton("Refresh IPs")
        refresh_ip_btn.setMaximumWidth(100)
        refresh_ip_btn.clicked.connect(self.refresh_local_ips)
        ip_row.addWidget(refresh_ip_btn)
        info_layout.addLayout(ip_row)
        listen_layout = QHBoxLayout()
        listen_layout.addWidget(QLabel("Listen Port:"))
        self.local_port_input = QLineEdit(str(self.server_port))
        self.local_port_input.setMaximumWidth(80)
        listen_layout.addWidget(self.local_port_input)
        self.restart_server_btn = QPushButton("Apply Port")
        self.restart_server_btn.setMaximumWidth(110)
        self.restart_server_btn.clicked.connect(self.restart_server)
        listen_layout.addWidget(self.restart_server_btn)
        listen_layout.addStretch()
        info_layout.addLayout(listen_layout)

        # Connect row
        connect_layout = QHBoxLayout()
        connect_layout.addWidget(QLabel("Peer IP:"))
        self.peer_ip_input = QLineEdit()
        self.peer_ip_input.setPlaceholderText("192.168.1.100")
        connect_layout.addWidget(self.peer_ip_input)
        connect_layout.addWidget(QLabel("Port:"))
        self.peer_port_input = QLineEdit(str(self.server_port))
        self.peer_port_input.setMaximumWidth(80)
        connect_layout.addWidget(self.peer_port_input)
        self.connect_button = QPushButton("Connect to Peer")
        self.connect_button.clicked.connect(self.connect_to_peer)
        connect_layout.addWidget(self.connect_button)

        # FIX: Disconnect button
        self.disconnect_button = QPushButton("Disconnect")
        self.disconnect_button.clicked.connect(self.disconnect_peer)
        self.disconnect_button.setEnabled(False)
        connect_layout.addWidget(self.disconnect_button)
        info_layout.addLayout(connect_layout)

        self.status_label = QLabel(f"Status: Server running on port {self.server_port}, waiting for connection")
        self.status_label.setFont(QFont("Arial", 10))
        info_layout.addWidget(self.status_label)
        info_group.setLayout(info_layout)
        main_layout.addWidget(info_group)

        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        # --- Chat Tab ---
        chat_tab = QWidget()
        chat_layout = QVBoxLayout(chat_tab)
        nick_layout = QHBoxLayout()
        nick_layout.addWidget(QLabel("Your Nickname:"))
        self.nickname_input = QLineEdit(self.local_nickname)
        self.nickname_input.setMaximumWidth(200)
        nick_layout.addWidget(self.nickname_input)
        nick_btn = QPushButton("Set Nickname")
        nick_btn.clicked.connect(self.set_nickname)
        nick_layout.addWidget(nick_btn)
        nick_layout.addStretch()
        chat_layout.addLayout(nick_layout)
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        chat_layout.addWidget(self.chat_display)
        input_layout = QHBoxLayout()
        self.chat_input = QLineEdit()
        self.chat_input.setPlaceholderText("Type message...")
        self.chat_input.returnPressed.connect(self.send_message)
        input_layout.addWidget(self.chat_input)
        self.send_button = QPushButton("Send")
        self.send_button.clicked.connect(self.send_message)
        self.send_button.setEnabled(False)
        input_layout.addWidget(self.send_button)
        chat_layout.addLayout(input_layout)
        self.tabs.addTab(chat_tab, "Chat")

        # --- File Transfer Tab ---
        file_tab = QWidget()
        file_layout = QVBoxLayout(file_tab)
        dl_group = QGroupBox("Download Folder")
        dl_layout = QHBoxLayout(dl_group)
        self.download_path_input = QLineEdit(self.download_directory)
        self.download_path_input.setReadOnly(True)
        browse_dl = QPushButton("Browse...")
        browse_dl.clicked.connect(self.browse_download_folder)
        dl_layout.addWidget(self.download_path_input)
        dl_layout.addWidget(browse_dl)
        file_layout.addWidget(dl_group)

        send_group = QGroupBox("Send File")
        send_layout = QVBoxLayout()
        sel_layout = QHBoxLayout()
        self.file_path_input = QLineEdit()
        self.file_path_input.setReadOnly(True)
        self.file_path_input.setPlaceholderText("No file selected")
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self.select_file)
        sel_layout.addWidget(self.file_path_input)
        sel_layout.addWidget(browse_btn)
        send_layout.addLayout(sel_layout)
        self.send_file_button = QPushButton("Send File")
        self.send_file_button.setEnabled(False)
        self.send_file_button.clicked.connect(self.send_file)
        send_layout.addWidget(self.send_file_button)
        send_group.setLayout(send_layout)
        file_layout.addWidget(send_group)

        xfer_group = QGroupBox("Transfers")
        xfer_layout = QVBoxLayout(xfer_group)
        self.transfer_table = QTableWidget()
        self.transfer_table.setColumnCount(6)
        self.transfer_table.setHorizontalHeaderLabels(["Direction", "File", "Size", "Progress", "Status", "Actions"])
        self.transfer_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.transfer_table.setColumnWidth(0, 80)
        self.transfer_table.setColumnWidth(3, 120)
        self.transfer_table.setColumnWidth(5, 100)
        self.transfer_table.horizontalHeader().setStretchLastSection(False)
        self.transfer_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.transfer_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.transfer_table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.transfer_table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.transfer_table.verticalHeader().setDefaultSectionSize(40)
        self.transfer_table.setStyleSheet("QTableWidget QTableCornerButton::section { background-color: #2d2d2d; }")
        xfer_layout.addWidget(self.transfer_table)
        file_layout.addWidget(xfer_group)
        file_layout.addStretch()
        self.tabs.addTab(file_tab, "File Transfer")

        # --- Diagnostics Tab --- wrapped in QScrollArea so all content is reachable
        diag_tab = QWidget()
        diag_tab_layout = QVBoxLayout(diag_tab)
        diag_tab_layout.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)

        diag_inner = QWidget()
        diag_layout = QVBoxLayout(diag_inner)
        diag_layout.setSpacing(8)

        # Shared explicit button style — bypasses any theme issue
        diag_btn_style = """
            QPushButton {
                background-color: #0d7377;
                color: #ffffff;
                font-size: 13px;
                font-weight: bold;
                border: none;
                padding: 10px 16px;
                border-radius: 4px;
                text-align: center;
            }
            QPushButton:hover { background-color: #14a085; }
            QPushButton:pressed { background-color: #0a5558; }
        """
        winsock_btn_style = """
            QPushButton {
                background-color: #8B0000;
                color: #ffffff;
                font-size: 13px;
                font-weight: bold;
                border: none;
                padding: 10px 16px;
                border-radius: 4px;
                text-align: center;
            }
            QPushButton:hover { background-color: #cc0000; }
            QPushButton:pressed { background-color: #600000; }
        """

        # Self-test group
        selftest_group = QGroupBox("Step 1 — Test Your Own Server")
        selftest_layout = QVBoxLayout(selftest_group)
        selftest_layout.addWidget(QLabel("Checks that your server is actually listening and accepting connections."))
        self.selftest_btn = QPushButton("Run Self-Test (connect to localhost)")
        self.selftest_btn.setStyleSheet(diag_btn_style)
        self.selftest_btn.clicked.connect(self.run_self_test)
        selftest_layout.addWidget(self.selftest_btn)
        self.selftest_result = QLabel("Result: not run yet")
        self.selftest_result.setWordWrap(True)
        selftest_layout.addWidget(self.selftest_result)
        diag_layout.addWidget(selftest_group)

        # Reachability group
        reach_group = QGroupBox("Step 2 — Test Peer Reachability")
        reach_layout = QVBoxLayout(reach_group)
        reach_layout.addWidget(QLabel("Attempts a raw TCP connection to the peer IP:Port. Does NOT require the app to connect — just checks if the port is open."))
        self.reach_btn = QPushButton("Test Peer Port (uses IP/Port from main panel)")
        self.reach_btn.setStyleSheet(diag_btn_style)
        self.reach_btn.clicked.connect(self.run_reach_test)
        reach_layout.addWidget(self.reach_btn)
        self.reach_result = QLabel("Result: not run yet")
        self.reach_result.setWordWrap(True)
        reach_layout.addWidget(self.reach_result)
        diag_layout.addWidget(reach_group)

        # Network info group
        netinfo_group = QGroupBox("Step 3 — Network Info & Subnet Check")
        netinfo_layout = QVBoxLayout(netinfo_group)
        self.refresh_netinfo_btn = QPushButton("Refresh Network Info")
        self.refresh_netinfo_btn.setStyleSheet(diag_btn_style)
        self.refresh_netinfo_btn.clicked.connect(self.refresh_netinfo)
        netinfo_layout.addWidget(self.refresh_netinfo_btn)
        self.netinfo_label = QLabel()
        self.netinfo_label.setWordWrap(True)
        self.netinfo_label.setFont(QFont("Courier", 9))
        netinfo_layout.addWidget(self.netinfo_label)
        diag_layout.addWidget(netinfo_group)

        # Common issues
        issues_group = QGroupBox("Common Issues")
        issues_layout = QVBoxLayout(issues_group)
        issues_text = QTextEdit()
        issues_text.setReadOnly(True)
        issues_text.setMaximumHeight(180)
        issues_text.setHtml("""
<b>❌ Different WiFi networks (most common!)</b><br>
Two PCs on different routers CANNOT connect directly — each is behind NAT.
Fix: use a VPN (Tailscale/ZeroTier is free and easy), or both connect to the same network.<br><br>
<b>❌ Windows Firewall blocking inbound</b><br>
Even on the same network, Windows blocks inbound connections by default.<br>
Fix: Windows Defender Firewall → Allow an app → add Python (or your .exe) for Private networks.
Or run in PowerShell as admin:<br>
<code>netsh advfirewall firewall add rule name="ToD" dir=in action=allow protocol=TCP localport=47000</code><br><br>
<b>❌ Wrong IP address</b><br>
Check "Your IPs" in the main panel — there may be multiple. Give your peer the one
on the same network as them (e.g. 192.168.x.x for LAN, 100.x.x.x for Tailscale VPN).<br><br>
<b>❌ Port already in use</b><br>
Another app or a crashed previous instance may be holding the port.
Try changing the Listen Port to something else and clicking Apply Port.
        """)
        issues_layout.addWidget(issues_text)
        diag_layout.addWidget(issues_group)

        # Winsock repair (Windows only)
        winsock_group = QGroupBox("Windows — Repair Winsock (fixes WinError 10013)")
        winsock_layout = QVBoxLayout(winsock_group)
        winsock_layout.addWidget(QLabel(
            "If you get WinError 10013, Tailscale may have corrupted the Windows socket stack.\n"
            "Click below — a UAC prompt will appear. You MUST reboot after for the fix to take effect."
        ))
        self.winsock_btn = QPushButton("Repair Winsock + Prompt Reboot  (Windows only)")
        self.winsock_btn.setStyleSheet(winsock_btn_style)
        self.winsock_btn.clicked.connect(self.repair_winsock)
        winsock_layout.addWidget(self.winsock_btn)
        self.winsock_result = QLabel("")
        self.winsock_result.setWordWrap(True)
        winsock_layout.addWidget(self.winsock_result)
        diag_layout.addWidget(winsock_group)
        if sys.platform != 'win32':
            winsock_group.setVisible(False)

        diag_layout.addStretch()
        scroll.setWidget(diag_inner)
        diag_tab_layout.addWidget(scroll)
        self.tabs.addTab(diag_tab, "Diagnostics")

        # Populate network info on startup
        self.refresh_netinfo()

    def run_self_test(self):
        """Try connecting to our own server on localhost."""
        self.selftest_result.setText("Testing...")
        QApplication.processEvents()
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(3)
            s.connect(('127.0.0.1', self.server_port))
            # Send a dummy byte so peek doesn't reject us as a raw probe,
            # then immediately close — the server will drop it gracefully
            s.send(b'\x00')
            s.close()
            self.selftest_result.setText(
                f"✅ PASS — Server is listening on port {self.server_port}. "
                f"Your server is working correctly.")
        except ConnectionRefusedError:
            self.selftest_result.setText(
                f"❌ FAIL — Connection refused on port {self.server_port}. "
                f"The server is NOT running. Try clicking 'Apply Port' to restart it.")
        except socket.timeout:
            self.selftest_result.setText(
                f"❌ FAIL — Timeout on port {self.server_port}.")
        except Exception as e:
            self.selftest_result.setText(f"❌ FAIL — {e}")

    def run_reach_test(self):
        """Try a raw TCP connect to the peer IP:Port."""
        peer_ip = self.peer_ip_input.text().strip()
        peer_port_str = self.peer_port_input.text().strip()
        if not peer_ip or not peer_port_str:
            self.reach_result.setText("⚠ Enter a Peer IP and Port in the main panel first.")
            return
        try:
            port = int(peer_port_str)
        except ValueError:
            self.reach_result.setText("⚠ Invalid port number.")
            return

        self.reach_result.setText(f"Testing {peer_ip}:{port} ...")
        QApplication.processEvents()

        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)
            s.connect((peer_ip, port))
            s.close()
            self.reach_result.setText(
                f"✅ PASS — Port {port} is open on {peer_ip}. "
                f"The peer's server is reachable. If the app still won't connect, check both are on same version.")
        except ConnectionRefusedError:
            self.reach_result.setText(
                f"❌ FAIL — Connection refused. {peer_ip}:{port} is reachable but the port is closed. "
                f"Is the app running on the peer? Is the port correct?")
        except socket.timeout:
            self.reach_result.setText(
                f"❌ FAIL — Timeout reaching {peer_ip}:{port}. "
                f"Most likely causes: (1) different networks/NAT blocking you, "
                f"(2) Windows Firewall on peer, (3) wrong IP address.")
        except OSError as e:
            self.reach_result.setText(
                f"❌ FAIL — {e}. "
                f"The IP {peer_ip} may not be routable from this machine.")

    def refresh_netinfo(self):
        """Show detailed network info and subnet compatibility check."""
        ips = get_all_local_ips()
        peer_ip = self.peer_ip_input.text().strip()

        lines = ["=== Your Network Interfaces ==="]
        for ip in ips:
            parts = ip.split('.')
            subnet = '.'.join(parts[:3]) + '.x'
            lines.append(f"  {ip}  (subnet: {subnet})")

        lines.append("")
        lines.append("=== Subnet Compatibility ===")
        if peer_ip:
            peer_parts = peer_ip.split('.')
            match = False
            for ip in ips:
                my_parts = ip.split('.')
                if my_parts[:3] == peer_parts[:3]:
                    lines.append(f"  ✅ {ip} and {peer_ip} are on the same subnet — direct connection should work")
                    match = True
            if not match:
                lines.append(f"  ❌ {peer_ip} is NOT on the same subnet as any of your IPs")
                lines.append(f"     Direct connection will FAIL unless you're using a VPN (Tailscale, ZeroTier, etc.)")
        else:
            lines.append("  (enter a peer IP in the main panel to check)")

        lines.append("")
        lines.append("=== Port Status ===")
        if self.server_listener and self.server_listener.isRunning():
            lines.append(f"  ✅ Port {self.server_port} — server thread is running")
        else:
            lines.append(f"  ❌ Port {self.server_port} — server thread is NOT running, click Apply Port to restart")

        self.netinfo_label.setText('\n'.join(lines))

    def repair_winsock(self):
        """Run netsh winsock reset elevated and prompt for reboot."""
        if sys.platform != 'win32':
            self.winsock_result.setText("This is Windows-only.")
            return

        self.winsock_result.setText("Running repair — a UAC prompt will appear...")
        QApplication.processEvents()

        try:
            import ctypes, subprocess
            # Run netsh winsock reset elevated via ShellExecuteW
            result = ctypes.windll.shell32.ShellExecuteW(
                None, "runas", "netsh", "winsock reset", None, 1
            )
            if result <= 32:
                self.winsock_result.setText(
                    f"❌ Failed to launch elevated command (code {result}). "
                    f"Try manually: open PowerShell as Admin and run: netsh winsock reset"
                )
                return

            # Prompt reboot
            reply = QMessageBox.question(
                self,
                "Winsock Reset",
                "Winsock reset command sent.\n\nYou MUST reboot for the fix to take effect.\n\nReboot now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                subprocess.run(["shutdown", "/r", "/t", "10", "/c",
                                "Rebooting to complete Winsock repair..."])
                self.winsock_result.setText("Rebooting in 10 seconds... Save your work!")
            else:
                self.winsock_result.setText(
                    "✅ Winsock reset complete — remember to reboot before retrying the connection."
                )
        except Exception as e:
            self.winsock_result.setText(
                f"❌ Error: {e}\n"
                f"Run manually as Admin: netsh winsock reset"
            )

    def apply_theme(self):
        if self.is_dark_mode:
            self.setStyleSheet("""
                QMainWindow, QWidget { background-color: #1e1e1e; color: #ffffff; }
                QGroupBox { border: 1px solid #555; border-radius: 5px; margin-top: 10px; font-weight: bold; background-color: #2d2d2d; }
                QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; padding: 5px; color: #fff; }
                QLineEdit, QTextEdit { background-color: #2d2d2d; border: 1px solid #555; color: #fff; padding: 5px; }
                QPushButton { background-color: #0d7377; color: white; border: none; padding: 10px 18px; border-radius: 4px; }
                QPushButton:hover { background-color: #14a085; }
                QPushButton:disabled { background-color: #555; color: #888; }
                QLabel { color: #fff; }
                QProgressBar { border: 1px solid #555; border-radius: 5px; text-align: center; background-color: #2d2d2d; color: #fff; }
                QProgressBar::chunk { background-color: #0d7377; }
                QTabWidget::pane { border: 1px solid #555; background-color: #1e1e1e; }
                QTabBar::tab { background-color: #2d2d2d; color: #fff; padding: 8px; border: 1px solid #555; }
                QTabBar::tab:selected { background-color: #0d7377; }
                QMenuBar { background-color: #2d2d2d; color: #fff; }
                QMenuBar::item:selected { background-color: #0d7377; }
                QMenu { background-color: #2d2d2d; color: #fff; }
                QMenu::item:selected { background-color: #0d7377; }
                QTableWidget { background-color: #2d2d2d; color: #fff; gridline-color: #555; }
                QTableWidget::item { padding: 5px; }
                QHeaderView::section { background-color: #3d3d3d; color: #fff; padding: 5px; border: 1px solid #555; }
                QScrollBar:vertical { background-color: #2d2d2d; width: 15px; }
                QScrollBar::handle:vertical { background-color: #555; min-height: 20px; border-radius: 7px; }
                QScrollBar::handle:vertical:hover { background-color: #0d7377; }
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
            """)
            # Style disconnect button red in dark mode
            self.disconnect_button.setStyleSheet("""
                QPushButton { background-color: #8B0000; color: white; border: none; padding: 10px 18px; border-radius: 4px; }
                QPushButton:hover { background-color: #cc0000; }
                QPushButton:disabled { background-color: #555; color: #888; }
            """)
        else:
            self.setStyleSheet("""
                QMainWindow, QWidget { background-color: #fff; color: #000; }
                QGroupBox { border: 1px solid #ccc; border-radius: 5px; margin-top: 10px; font-weight: bold; background-color: #f5f5f5; }
                QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; padding: 5px; color: #000; }
                QLineEdit, QTextEdit { background-color: #fff; border: 1px solid #ccc; color: #000; padding: 5px; }
                QPushButton { background-color: #0d7377; color: white; border: none; padding: 10px 18px; border-radius: 4px; }
                QPushButton:hover { background-color: #14a085; }
                QPushButton:disabled { background-color: #ccc; color: #666; }
                QLabel { color: #000; }
                QProgressBar { border: 1px solid #ccc; border-radius: 5px; text-align: center; background-color: #fff; }
                QProgressBar::chunk { background-color: #0d7377; }
                QTabWidget::pane { border: 1px solid #ccc; background-color: #fff; }
                QTabBar::tab { background-color: #fff; color: #000; padding: 8px; border: 1px solid #ccc; }
                QTabBar::tab:selected { background-color: #0d7377; color: #fff; }
                QMenuBar { background-color: #fff; color: #000; }
                QMenuBar::item:selected { background-color: #0d7377; color: #fff; }
                QMenu { background-color: #fff; color: #000; }
                QMenu::item:selected { background-color: #0d7377; color: #fff; }
                QTableWidget { background-color: #fff; color: #000; gridline-color: #ccc; }
                QTableWidget::item { padding: 5px; }
                QHeaderView::section { background-color: #f0f0f0; color: #000; padding: 5px; border: 1px solid #ccc; }
                QScrollBar:vertical { background-color: #f0f0f0; width: 15px; }
                QScrollBar::handle:vertical { background-color: #ccc; min-height: 20px; border-radius: 7px; }
                QScrollBar::handle:vertical:hover { background-color: #0d7377; }
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
            """)
            self.disconnect_button.setStyleSheet("""
                QPushButton { background-color: #cc0000; color: white; border: none; padding: 10px 18px; border-radius: 4px; }
                QPushButton:hover { background-color: #ff0000; }
                QPushButton:disabled { background-color: #ccc; color: #666; }
            """)

    def toggle_theme(self):
        self.is_dark_mode = not self.is_dark_mode
        self.settings.setValue("dark_mode", self.is_dark_mode)
        self.apply_theme()

    def refresh_local_ips(self):
        """Re-detect all local IPs - useful if Tailscale connected after app started."""
        self.local_ips = get_all_local_ips()
        ips_display = "\n".join(self.local_ips) if len(self.local_ips) > 3 else "  |  ".join(self.local_ips)
        self.local_ip_label.setText(f"Your IPs: {ips_display}")
        if hasattr(self, 'netinfo_label'):
            self.refresh_netinfo()

    def start_server(self):
        try:
            self.server_listener = ServerListener(self.server_port)
            self.server_listener.new_connection.connect(self.handle_incoming_connection)
            self.server_listener.start()
            print(f"Server started on port {self.server_port}")
        except Exception as e:
            self.status_label.setText(f"Status: Server error: {e}")

    def restart_server(self):
        """Apply a new listen port and restart server."""
        try:
            new_port = int(self.local_port_input.text().strip())
        except ValueError:
            QMessageBox.warning(self, "Error", "Invalid port number")
            return
        if self.server_listener:
            self.server_listener.stop()
            self.server_listener.wait(2000)
            self.server_listener = None
        self.server_port = new_port
        self.settings.setValue("server_port", new_port)
        self.peer_port_input.setText(str(new_port))
        self.start_server()
        self.status_label.setText(f"Status: Server restarted on port {self.server_port}")

    # ---------------------------------------------------------------
    # FIX 1: _teardown_connection - properly tears down ALL resources
    # ---------------------------------------------------------------
    def _teardown_connection(self):
        """Completely tear down all connection resources. Safe to call at any time."""
        print("Tearing down connection...")

        # Disconnect signal first to prevent spurious connection_lost signals
        if self.listener_thread:
            try:
                self.listener_thread.connection_lost.disconnect()
            except:
                pass
            self.listener_thread.stop()
            self.listener_thread.wait(2000)
            self.listener_thread = None

        # Cancel active transfers
        for tid, manager in list(self.transfer_managers.items()):
            manager.cancel()
            manager.wait(2000)
        self.transfer_managers.clear()

        # Close file if receiving
        if self.receiving_file and self.incoming_file:
            try:
                self.incoming_file.close()
            except:
                pass
        self.receiving_file = False
        self.incoming_file = None
        self.current_transfer_id = None

        # Close socket last
        if self.current_peer_socket:
            self.current_peer_socket.close()
            self.current_peer_socket = None

        print("Teardown complete")

    # ---------------------------------------------------------------
    # FIX 2: _setup_connection - unified connection setup
    # ---------------------------------------------------------------
    def _setup_connection(self, sock: DirectSocket):
        """Set up a new connection - start listener, send nickname, update UI."""
        self.current_peer_socket = sock

        # Send our nickname immediately
        try:
            self.current_peer_socket.send_data(self.local_nickname.encode('utf-8'), DataPacketType.NICKNAME)
        except Exception as e:
            print(f"Warning: could not send nickname: {e}")

        self.send_button.setEnabled(True)
        self.send_file_button.setEnabled(self.selected_file_path != "")
        self.disconnect_button.setEnabled(True)
        self.connect_button.setEnabled(False)

        self.listener_thread = SocketListener(self.current_peer_socket)
        self.listener_thread.new_message.connect(self.handle_incoming_message)
        self.listener_thread.peer_nickname_received.connect(self.handle_incoming_nickname)
        self.listener_thread.file_start_received.connect(self.handle_file_start)
        self.listener_thread.file_chunk_received.connect(self.handle_file_chunk)
        self.listener_thread.file_end_received.connect(self.handle_file_end)
        self.listener_thread.file_cancel_received.connect(self.handle_file_cancel)
        self.listener_thread.file_ack_received.connect(self.handle_file_ack)
        self.listener_thread.connection_lost.connect(self.handle_connection_lost)
        self.listener_thread.start()
        print("Connection setup complete")

    def handle_incoming_connection(self, sock: DirectSocket):
        """Accept new connection - peek for real app handshake, ignore raw probes."""
        try:
            peer_addr = sock.raw_socket.getpeername()
            peer_ip = f"{peer_addr[0]}:{peer_addr[1]}"
        except:
            peer_ip = "unknown"

        # Peek: wait briefly for first real packet. Raw TCP probes (diagnostics,
        # port scanners) connect and immediately close — they send no data.
        try:
            sock.raw_socket.settimeout(2.0)
            peek = sock.raw_socket.recv(5, socket.MSG_PEEK)
            sock.raw_socket.settimeout(None)
            if not peek:
                print(f"Probe/empty connection from {peer_ip} — ignoring")
                sock.close()
                return
        except socket.timeout:
            print(f"No handshake from {peer_ip} within 2s — ignoring probe")
            sock.close()
            return
        except Exception as e:
            print(f"Peek error from {peer_ip}: {e} — ignoring")
            sock.close()
            return

        print(f"Real connection from {peer_ip}")

        if self.current_peer_socket is not None:
            print("Replacing existing connection")
            self._teardown_connection()

        self.status_label.setText(f"Status: Connected - peer {peer_ip}")
        self._setup_connection(sock)

    def connect_to_peer(self):
        """FIX: Tear down existing connection before connecting outbound."""
        peer_ip = self.peer_ip_input.text().strip()
        peer_port_str = self.peer_port_input.text().strip()

        if not peer_ip or not peer_port_str:
            QMessageBox.warning(self, "Error", "Enter peer IP and port")
            return
        try:
            port = int(peer_port_str)
        except ValueError:
            QMessageBox.warning(self, "Error", "Invalid port number")
            return

        # FIX: Always clean up before connecting
        if self.current_peer_socket is not None:
            print("Dropping existing connection before reconnecting")
            self._teardown_connection()

        self.status_label.setText(f"Status: Connecting to {peer_ip}:{port}...")
        self.connect_button.setEnabled(False)
        QApplication.processEvents()

        try:
            raw_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            raw_socket.settimeout(30)
            raw_socket.connect((peer_ip, port))
            raw_socket.settimeout(None)  # Let DirectSocket manage timeout
            wrapped = DirectSocket(raw_socket)
            self.status_label.setText(f"Status: Connected to {peer_ip}:{port}")
            self._setup_connection(wrapped)
        except socket.timeout:
            self.status_label.setText(f"Status: Timed out connecting to {peer_ip}:{port}")
            self.connect_button.setEnabled(True)
        except ConnectionRefusedError:
            self.status_label.setText(f"Status: Connection refused - is the app running on {peer_ip}:{port}?")
            self.connect_button.setEnabled(True)
        except Exception as e:
            self.status_label.setText(f"Status: Connection failed: {e}")
            self.connect_button.setEnabled(True)

    def disconnect_peer(self):
        """FIX: Manual disconnect with full cleanup."""
        print("Manual disconnect")
        self._teardown_connection()
        self.status_label.setText(f"Status: Disconnected - server still listening on port {self.server_port}")
        self.send_button.setEnabled(False)
        self.send_file_button.setEnabled(False)
        self.disconnect_button.setEnabled(False)
        self.connect_button.setEnabled(True)
        self.chat_display.append("<span style='color: orange;'>--- Disconnected ---</span>")

    def handle_connection_lost(self, error_msg: str):
        """FIX: Full cleanup on unexpected disconnect."""
        print(f"Connection lost: {error_msg}")
        self._teardown_connection()
        self.status_label.setText(f"Status: {error_msg} - server still listening on port {self.server_port}")
        self.chat_display.append(f"<span style='color: red;'>--- {error_msg} ---</span>")
        self.send_button.setEnabled(False)
        self.send_file_button.setEnabled(False)
        self.disconnect_button.setEnabled(False)
        self.connect_button.setEnabled(True)

    def set_nickname(self):
        nickname = self.nickname_input.text().strip()
        if nickname and len(nickname) <= 50:
            self.local_nickname = nickname
            self.settings.setValue("local_nickname", nickname)
            if self.current_peer_socket:
                try:
                    self.current_peer_socket.send_data(nickname.encode('utf-8'), DataPacketType.NICKNAME)
                    self.chat_display.append(f"<span style='color: orange;'>--- Your nickname: {nickname} ---</span>")
                except:
                    pass

    def handle_incoming_nickname(self, data: bytes):
        try:
            name = data.decode('utf-8').strip()
            if name:
                self.peer_nickname = name
                self.chat_display.append(f"<span style='color: orange;'>--- Peer: {name} ---</span>")
        except:
            pass

    def send_message(self):
        if not self.send_button.isEnabled():
            return
        message = self.chat_input.text()
        if not message.strip():
            return
        try:
            self.current_peer_socket.send_data(message.encode('utf-8'), DataPacketType.CHAT)
            self.chat_display.append(f"<span style='color: #4CAF50;'>{self.local_nickname}: {message}</span>")
            self.chat_input.clear()
        except Exception as e:
            self.status_label.setText(f"Status: Send error: {e}")

    def handle_incoming_message(self, data: bytes):
        try:
            self.chat_display.append(f"<span style='color: #2196F3;'>{self.peer_nickname}: {data.decode('utf-8')}</span>")
        except:
            self.chat_display.append("<span style='color: red;'>--- Message decode error ---</span>")

    def browse_download_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Download Folder", self.download_directory)
        if folder:
            self.download_directory = folder
            self.download_path_input.setText(folder)
            self.settings.setValue("download_directory", folder)

    def add_transfer_to_table(self, tid: int, direction: str, filename: str, filesize: int):
        row = self.transfer_table.rowCount()
        self.transfer_table.insertRow(row)
        self.transfer_rows[tid] = row
        self.transfer_sizes[tid] = filesize
        self.transfer_table.setItem(row, 0, QTableWidgetItem(direction))
        self.transfer_table.setItem(row, 1, QTableWidgetItem(filename))
        self.transfer_table.setItem(row, 2, QTableWidgetItem(format_file_size(filesize)))
        pb = QProgressBar()
        pb.setMaximum(100)
        pb.setValue(0)
        pb.setFormat("%p%")
        self.transfer_table.setCellWidget(row, 3, pb)
        status = "Waiting for ACK..." if direction == "Send" else "Starting..."
        self.transfer_table.setItem(row, 4, QTableWidgetItem(status))
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setStyleSheet("""
            QPushButton { background-color: #d32f2f; color: white; border: none; padding: 10px 18px; }
            QPushButton:hover { background-color: #f44336; }
            QPushButton:disabled { background-color: #888; }
        """)
        cancel_btn.setMinimumHeight(30)
        cancel_btn.clicked.connect(lambda: self.cancel_transfer(tid))
        self.transfer_table.setCellWidget(row, 5, cancel_btn)

    def cancel_transfer(self, tid: int):
        if tid not in self.transfer_rows:
            return
        row = self.transfer_rows[tid]
        if tid in self.transfer_managers:
            self.transfer_managers[tid].cancel()
        if self.receiving_file and self.current_transfer_id == tid:
            if self.incoming_file:
                self.incoming_file.close()
            self.receiving_file = False
            try:
                self.current_peer_socket.send_data(b'', DataPacketType.FILE_CANCEL)
            except:
                pass
        self.transfer_table.setItem(row, 4, QTableWidgetItem("Cancelled"))
        btn = self.transfer_table.cellWidget(row, 5)
        if btn:
            btn.setEnabled(False)

    def update_transfer_progress(self, tid: int, done: int, total: int, status: str = None):
        if tid not in self.transfer_rows:
            return
        row = self.transfer_rows[tid]
        pb = self.transfer_table.cellWidget(row, 3)
        if pb and total > 0:
            pb.setValue(min(99, int(done / total * 100)))
        if status:
            self.transfer_table.setItem(row, 4, QTableWidgetItem(status))

    def complete_transfer(self, tid: int, success: bool, message: str = ""):
        if tid not in self.transfer_rows:
            return
        row = self.transfer_rows[tid]
        if success:
            self.transfer_table.setItem(row, 4, QTableWidgetItem("Complete"))
            pb = self.transfer_table.cellWidget(row, 3)
            if pb:
                pb.setValue(100)
        else:
            self.transfer_table.setItem(row, 4, QTableWidgetItem(f"Failed: {message}" if message else "Failed"))
        btn = self.transfer_table.cellWidget(row, 5)
        if btn:
            btn.setEnabled(False)
        self.transfer_sizes.pop(tid, None)
        if tid in self.transfer_managers:
            self.transfer_managers[tid].wait(5000)
            del self.transfer_managers[tid]

    def select_file(self):
        filepath, _ = QFileDialog.getOpenFileName(self, "Select File")
        if filepath:
            self.selected_file_path = filepath
            name = Path(filepath).name
            size = Path(filepath).stat().st_size
            self.file_path_input.setText(f"{name} ({format_file_size(size)})")
            self.send_file_button.setEnabled(self.current_peer_socket is not None)

    def send_file(self):
        if not self.selected_file_path or not self.current_peer_socket:
            return
        try:
            tid = self.next_transfer_id
            self.next_transfer_id += 1
            fp = Path(self.selected_file_path)
            self.add_transfer_to_table(tid, "Send", fp.name, fp.stat().st_size)
            self.send_file_button.setEnabled(False)
            manager = FileTransferManager(self.current_peer_socket, self.selected_file_path)
            manager.transfer_id = tid
            self.transfer_managers[tid] = manager
            self.transfer_manager = manager
            manager.progress_update.connect(lambda b, t: self.update_send_progress(tid, b, t))
            manager.transfer_complete.connect(lambda: self.send_complete(tid))
            manager.transfer_error.connect(lambda err: self.send_error(tid, err))
            manager.start()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to start transfer: {e}")
            self.send_file_button.setEnabled(True)

    def update_send_progress(self, tid: int, sent: int, total: int):
        actual = self.transfer_sizes.get(tid, total)
        self.update_transfer_progress(tid, sent, actual,
            f"Sending {format_file_size(sent)} / {format_file_size(actual)}")

    def send_complete(self, tid: int):
        self.complete_transfer(tid, True)
        self.send_file_button.setEnabled(True)
        self.chat_display.append("<span style='color: green;'>--- File sent ---</span>")

    def send_error(self, tid: int, error: str):
        self.complete_transfer(tid, False, error)
        self.send_file_button.setEnabled(True)

    def handle_file_start(self, filename: str, filesize: int):
        print(f"FILE RECEIVE: {filename} ({format_file_size(filesize)})")
        tid = self.next_transfer_id
        self.next_transfer_id += 1
        self.current_transfer_id = tid
        self.add_transfer_to_table(tid, "Receive", filename, filesize)
        self.incoming_filename = filename
        self.incoming_filesize = filesize
        self.incoming_bytes_received = 0
        try:
            fp = Path(self.download_directory) / filename
            if fp.exists():
                base, ext, c = fp.stem, fp.suffix, 1
                while fp.exists():
                    fp = Path(self.download_directory) / f"{base}_{c}{ext}"
                    c += 1
            self.incoming_file = open(fp, 'wb')
            self.receiving_file = True
            self.current_peer_socket.send_data(b'', DataPacketType.FILE_ACK)
            print("FILE RECEIVE: ACK sent")
        except Exception as e:
            print(f"FILE RECEIVE: Error: {e}")
            self.complete_transfer(tid, False, str(e))

    def handle_file_chunk(self, chunk: bytes):
        if self.receiving_file and self.incoming_file:
            try:
                self.incoming_file.write(chunk)
                self.incoming_bytes_received += len(chunk)
                total = self.transfer_sizes.get(self.current_transfer_id, self.incoming_filesize)
                self.update_transfer_progress(self.current_transfer_id, self.incoming_bytes_received, total,
                    f"Receiving {format_file_size(self.incoming_bytes_received)} / {format_file_size(total)}")
            except Exception as e:
                self.complete_transfer(self.current_transfer_id, False, str(e))

    def handle_file_end(self):
        if self.receiving_file and self.incoming_file:
            try:
                self.incoming_file.close()
                self.receiving_file = False
                self.complete_transfer(self.current_transfer_id, True)
                self.chat_display.append(f"<span style='color: green;'>--- Received: {self.incoming_filename} ---</span>")
            except Exception as e:
                self.complete_transfer(self.current_transfer_id, False, str(e))

    def handle_file_cancel(self):
        if self.receiving_file and self.incoming_file:
            self.incoming_file.close()
            self.receiving_file = False
            if self.current_transfer_id is not None:
                self.complete_transfer(self.current_transfer_id, False, "Cancelled by sender")
            self.chat_display.append("<span style='color: red;'>--- Transfer cancelled by peer ---</span>")

    def handle_file_ack(self):
        """FIX: Route ACK to the correct active transfer manager."""
        print("Received FILE_ACK")
        # Find the running manager that's waiting for ACK
        active = [m for m in self.transfer_managers.values() if m.isRunning() and not m.ack_received.is_set()]
        if active:
            active[-1].acknowledge_received()
        elif self.transfer_manager:
            self.transfer_manager.acknowledge_received()

    def closeEvent(self, event):
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("dark_mode", self.is_dark_mode)
        self.settings.setValue("local_nickname", self.local_nickname)
        self.settings.setValue("download_directory", self.download_directory)
        self.settings.setValue("server_port", self.server_port)
        for tid, manager in list(self.transfer_managers.items()):
            manager.cancel()
            manager.wait(2000)
        if self.listener_thread:
            self.listener_thread.stop()
            self.listener_thread.wait(2000)
        if self.server_listener:
            self.server_listener.stop()
            self.server_listener.wait(2000)
        if self.current_peer_socket:
            self.current_peer_socket.close()
        event.accept()


# --- SPLASH SCREEN ---

def create_splash():
    try:
        splash_path = Path(resource_path("splash.png"))
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                raise ValueError("Null pixmap")
            pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                   Qt.TransformationMode.SmoothTransformation)
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))

        painter = QPainter(pixmap)
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
        r = pixmap.rect()
        r.setTop(40); r.setBottom(100)
        painter.drawText(r, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        fr = pixmap.rect()
        fr.setTop(pixmap.height() - 100); fr.setBottom(pixmap.height() - 50)
        painter.drawText(fr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
        painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print(f"Splash error: {e}")
        return None


def main():
    if not LIBS_AVAILABLE:
        return

    # Tell Windows to use our icon in the taskbar instead of Python's
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "DeathsHeadSoftware.TransferOfDeath.1")
    except:
        pass  # Non-Windows platforms ignore this
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    icon = load_app_icon()
    if icon:
        app.setWindowIcon(icon)
    splash = create_splash()
    if splash:
        splash.show()
        msgs = [
            "Initializing Transfer of Death v3.6...",
            "Detecting all local network interfaces...",
            "Configuring direct peer-to-peer connections...",
            "Loading connection reliability engine...",
            "Starting server listener...",
            "System ready!"
        ]
        for msg in msgs:
            splash.showMessage("\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255))
            app.processEvents()
            time.sleep(0.4)
    window = TransferOfDeath()
    window.show()
    if splash:
        splash.finish(window)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
